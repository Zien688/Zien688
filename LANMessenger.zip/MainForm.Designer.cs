// MainForm.Designer.cs
namespace LANMessenger
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.ListBox listIPs;
        private System.Windows.Forms.Panel chatPanel;

        private void InitializeComponent()
        {
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.listIPs = new System.Windows.Forms.ListBox();
            this.chatPanel = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.SuspendLayout();

            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Name = "splitContainer";

            this.splitContainer.Panel1.Controls.Add(this.listIPs);
            this.splitContainer.Panel2.Controls.Add(this.chatPanel);

            this.listIPs.Dock = System.Windows.Forms.DockStyle.Fill;

            this.chatPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chatPanel.AutoScroll = true;

            this.Controls.Add(this.splitContainer);
            this.Text = "LAN Messenger";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
        }
    }
}
