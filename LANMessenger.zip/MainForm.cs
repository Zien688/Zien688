// MainForm.cs
using System;
using System.Net;
using System.Windows.Forms;

namespace LANMessenger
{
    public partial class MainForm : Form
    {
        private NetworkManager networkManager;

        public MainForm()
        {
            InitializeComponent();
            var localIP = Dns.GetHostEntry(Dns.GetHostName())
                             .AddressList[0]; // Giả định IP đầu tiên là IP LAN
            networkManager = new NetworkManager(localIP);
            networkManager.MessageReceived += NetworkManager_MessageReceived;
            networkManager.StatusUpdated += NetworkManager_StatusUpdated;
            networkManager.StartListening();
        }

        private void NetworkManager_MessageReceived(object sender, (IPAddress ip, string message) e)
        {
            // TODO: Hiển thị tin nhắn dạng bubble
        }

        private void NetworkManager_StatusUpdated(object sender, (IPAddress ip, string status) e)
        {
            // TODO: Cập nhật trạng thái "đang nhập", "đã xem"
        }
    }
}
