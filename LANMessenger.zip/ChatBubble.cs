// ChatBubble.cs
using System;
using System.Drawing;
using System.Windows.Forms;

namespace LANMessenger
{
    public class ChatBubble : UserControl
    {
        private Label messageLabel;
        private ToolTip timeTip;

        public ChatBubble(string message, DateTime time, bool isMine)
        {
            this.messageLabel = new Label();
            this.timeTip = new ToolTip();

            this.messageLabel.Text = message;
            this.messageLabel.AutoSize = true;
            this.messageLabel.MaximumSize = new Size(300, 0);
            this.messageLabel.BackColor = isMine ? Color.LightBlue : Color.LightGray;
            this.messageLabel.Padding = new Padding(10);
            this.messageLabel.Margin = new Padding(5);
            this.messageLabel.TextAlign = ContentAlignment.MiddleLeft;

            this.timeTip.SetToolTip(this.messageLabel, time.ToString("HH:mm:ss"));

            this.Controls.Add(this.messageLabel);
            this.Dock = DockStyle.Top;
            this.AutoSize = true;
        }
    }
}
