// NetworkManager.cs
using System;
using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LANMessenger
{
    public class NetworkManager
    {
        private const int Port = 9000;
        private TcpListener serverListener;
        private CancellationTokenSource cts;
        private ConcurrentDictionary<IPAddress, TcpClient> clients = new();
        private IPAddress localIP;

        public event EventHandler<(IPAddress ip, string message)> MessageReceived;
        public event EventHandler<(IPAddress ip, string status)> StatusUpdated;

        public NetworkManager(IPAddress localIP)
        {
            this.localIP = localIP;
        }

        public void StartListening()
        {
            cts = new CancellationTokenSource();
            serverListener = new TcpListener(IPAddress.Any, Port);
            serverListener.Start();
            Task.Run(() => AcceptClientsAsync(cts.Token));
        }

        public void Stop()
        {
            cts.Cancel();
            foreach (var c in clients.Values)
                c.Close();
            serverListener.Stop();
        }

        private async Task AcceptClientsAsync(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    var client = await serverListener.AcceptTcpClientAsync();
                    var remoteEP = client.Client.RemoteEndPoint as IPEndPoint;
                    if (remoteEP != null)
                    {
                        var ip = remoteEP.Address;
                        clients[ip] = client;
                        _ = Task.Run(() => HandleClientAsync(client, ip, token));
                    }
                }
                catch { }
            }
        }

        private async Task HandleClientAsync(TcpClient client, IPAddress ip, CancellationToken token)
        {
            var stream = client.GetStream();
            byte[] buffer = new byte[4096];
            while (!token.IsCancellationRequested && client.Connected)
            {
                try
                {
                    int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length, token);
                    if (bytesRead == 0)
                    {
                        clients.TryRemove(ip, out _);
                        client.Close();
                        break;
                    }

                    string msg = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                    ParseMessage(ip, msg);
                }
                catch
                {
                    clients.TryRemove(ip, out _);
                    client.Close();
                    break;
                }
            }
        }

        private void ParseMessage(IPAddress ip, string msg)
        {
            if (msg.StartsWith("MSG:"))
            {
                string text = msg.Substring(4);
                MessageReceived?.Invoke(this, (ip, text));
            }
            else if (msg.StartsWith("STATUS:"))
            {
                string status = msg.Substring(7);
                StatusUpdated?.Invoke(this, (ip, status));
            }
        }

        public void SendMessage(IPAddress ip, string message)
        {
            Send(ip, "MSG:" + message);
        }

        public void SendStatus(IPAddress ip, string status)
        {
            Send(ip, "STATUS:" + status);
        }

        private void Send(IPAddress ip, string data)
        {
            Task.Run(() =>
            {
                try
                {
                    if (!clients.ContainsKey(ip))
                    {
                        var client = new TcpClient();
                        client.Connect(ip, Port);
                        clients[ip] = client;
                        _ = Task.Run(() => HandleClientAsync(client, ip, CancellationToken.None));
                    }

                    var clientToSend = clients[ip];
                    if (clientToSend.Connected)
                    {
                        var stream = clientToSend.GetStream();
                        byte[] bytes = Encoding.UTF8.GetBytes(data);
                        stream.Write(bytes, 0, bytes.Length);
                    }
                }
                catch
                {
                    clients.TryRemove(ip, out _);
                }
            });
        }
    }
}
