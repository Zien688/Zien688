
using System;
using System.Windows.Forms;
using MessengerApp.Network;

namespace MessengerApp.Controls
{
    public partial class ChatBoxControl : UserControl
    {
        private string remoteIP;
        private RichTextBox txtChat;
        private TextBox txtInput;
        private Button btnSend;

        public ChatBoxControl(string ip)
        {
            remoteIP = ip;
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            this.Dock = DockStyle.Fill;

            txtChat = new RichTextBox
            {
                Dock = DockStyle.Top,
                Height = 300,
                ReadOnly = true
            };
            this.Controls.Add(txtChat);

            txtInput = new TextBox
            {
                Dock = DockStyle.Bottom
            };
            this.Controls.Add(txtInput);

            btnSend = new Button
            {
                Text = "Gửi",
                Dock = DockStyle.Bottom
            };
            btnSend.Click += BtnSend_Click;
            this.Controls.Add(btnSend);
        }

        private void BtnSend_Click(object sender, EventArgs e)
        {
            string message = txtInput.Text.Trim();
            if (string.IsNullOrEmpty(message)) return;

            AddMessage("Tôi", message);
            txtInput.Clear();
            ChatClient.SendMessage(remoteIP, message);
        }

        public void AddMessage(string senderName, string message)
        {
            txtChat.AppendText($"{DateTime.Now:HH:mm} {senderName}: {message}
");
        }
    }
}
