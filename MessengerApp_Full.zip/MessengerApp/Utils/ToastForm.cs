
using System;
using System.Drawing;
using System.Windows.Forms;

namespace MessengerApp.Utils
{
    public class ToastForm : Form
    {
        private Timer timer;

        public ToastForm(string message)
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.Manual;
            this.BackColor = Color.LightYellow;
            this.Size = new Size(300, 80);
            this.TopMost = true;

            var label = new Label()
            {
                Text = message,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 10)
            };
            this.Controls.Add(label);

            int x = Screen.PrimaryScreen.WorkingArea.Width - this.Width - 10;
            int y = Screen.PrimaryScreen.WorkingArea.Height - this.Height - 10;
            this.Location = new Point(x, y);

            timer = new Timer { Interval = 3000 };
            timer.Tick += (s, e) => this.Close();
            timer.Start();
        }
    }
}
