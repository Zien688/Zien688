
using System;
using System.Net.Sockets;
using System.Text;

namespace MessengerApp.Network
{
    public class ChatClient
    {
        public static void SendMessage(string ip, string message)
        {
            try
            {
                using (TcpClient client = new TcpClient(ip, 9000))
                using (NetworkStream stream = client.GetStream())
                {
                    byte[] data = Encoding.UTF8.GetBytes(message);
                    stream.Write(data, 0, data.Length);
                }
            }
            catch { }
        }
    }
}
