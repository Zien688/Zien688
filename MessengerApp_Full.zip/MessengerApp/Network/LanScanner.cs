
using System.Collections.Generic;
using System.Net;
using System.Net.NetworkInformation;

namespace MessengerApp.Network
{
    public class LanScanner
    {
        public static List<string> GetLocalIPs()
        {
            List<string> ipList = new List<string>();
            string localIP = GetLocalIPAddress();
            string baseIP = localIP.Substring(0, localIP.LastIndexOf('.') + 1);

            for (int i = 1; i < 255; i++)
            {
                string ip = baseIP + i.ToString();
                if (PingHost(ip))
                {
                    ipList.Add(ip);
                }
            }

            return ipList;
        }

        private static bool PingHost(string address)
        {
            try
            {
                Ping ping = new Ping();
                var reply = ping.Send(address, 50);
                return reply.Status == IPStatus.Success;
            }
            catch { return false; }
        }

        private static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            return "127.0.0.1";
        }
    }
}
