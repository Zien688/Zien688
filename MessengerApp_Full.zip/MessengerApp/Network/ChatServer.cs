
using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace MessengerApp.Network
{
    public class ChatServer
    {
        public delegate void MessageReceivedHandler(string senderIP, string message);
        public event MessageReceivedHandler MessageReceived;

        public void StartListening()
        {
            TcpListener listener = new TcpListener(IPAddress.Any, 9000);
            listener.Start();

            Task.Run(() =>
            {
                while (true)
                {
                    var client = listener.AcceptTcpClient();
                    Task.Run(() => HandleClient(client));
                }
            });
        }

        private void HandleClient(TcpClient client)
        {
            using (var stream = client.GetStream())
            using (var reader = new StreamReader(stream, Encoding.UTF8))
            {
                string msg = reader.ReadToEnd();
                string senderIP = ((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString();
                MessageReceived?.Invoke(senderIP, msg);
            }
        }
    }
}
