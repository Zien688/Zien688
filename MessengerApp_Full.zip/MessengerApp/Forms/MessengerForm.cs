
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using MessengerApp.Controls;
using MessengerApp.Network;
using MessengerApp.Utils;

namespace MessengerApp.Forms
{
    public partial class MessengerForm : Form
    {
        private Dictionary<string, ChatBoxControl> chatBoxes = new Dictionary<string, ChatBoxControl>();
        private ChatServer server;

        public MessengerForm()
        {
            InitializeComponent();
            InitializeLayout();
            LoadOnlineUsers();
            StartChatServer();
        }

        private void InitializeLayout()
        {
            this.Text = "LAN Messenger";
            this.Width = 800;
            this.Height = 600;

            var panelLeft = new FlowLayoutPanel
            {
                Name = "panelLeft",
                Width = 200,
                Dock = DockStyle.Left,
                AutoScroll = true
            };
            this.Controls.Add(panelLeft);

            var panelRight = new Panel
            {
                Name = "panelRight",
                Dock = DockStyle.Fill
            };
            this.Controls.Add(panelRight);
        }

        private void LoadOnlineUsers()
        {
            var ipList = LanScanner.GetLocalIPs();

            var panelLeft = this.Controls["panelLeft"] as FlowLayoutPanel;

            foreach (var ip in ipList)
            {
                var btn = new Button
                {
                    Text = ip,
                    Width = panelLeft.Width - 10,
                    Height = 40,
                    Tag = ip
                };
                btn.Click += (s, e) => OpenChatWithIP(ip);
                panelLeft.Controls.Add(btn);
            }
        }

        private void OpenChatWithIP(string ip)
        {
            var panelRight = this.Controls["panelRight"];

            if (!chatBoxes.ContainsKey(ip))
            {
                var chatBox = new ChatBoxControl(ip);
                chatBox.Dock = DockStyle.Fill;
                chatBoxes[ip] = chatBox;
            }

            panelRight.Controls.Clear();
            panelRight.Controls.Add(chatBoxes[ip]);
        }

        private void StartChatServer()
        {
            server = new ChatServer();
            server.MessageReceived += (senderIP, message) =>
            {
                this.Invoke(new Action(() =>
                {
                    if (!chatBoxes.ContainsKey(senderIP))
                        OpenChatWithIP(senderIP);
                    chatBoxes[senderIP].AddMessage(senderIP, message);
                    new ToastForm($"Tin nhắn mới từ {senderIP}").Show();
                }));
            };
            server.StartListening();
        }
    }
}
