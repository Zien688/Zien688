
📌 Hướng dẫn sử dụng BarcodeGenerator.xlsx

1. Cài font:
   - Mở file 'Code128.ttf' và nhấn Install.
   - Hoặc tải font thật từ: https://www.dafontfree.net/freefonts-code-128-f97334.htm

2. Mở file BarcodeGenerator.xlsx:
   - Nhập nội dung cần tạo mã vạch vào cột A.
   - Cột B sẽ chứa công thức tạo mã hóa Code128 (hàm sẽ được thêm bằng VBA).
   - Đặt font của cột B là 'Code128' (hoặc font bạn đã cài).

3. Tăng cỡ chữ lên khoảng 24–36 để máy scan dễ đọc.

✅ Bạn có thể scan trực tiếp bằng máy đọc mã vạch sau khi nhập và chọn đúng font.
