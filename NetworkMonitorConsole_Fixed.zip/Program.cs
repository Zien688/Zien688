
using System;
using System.Diagnostics;
using System.Linq;
using System.Net.NetworkInformation;
using System.Threading;

class Program
{
    static void Main()
    {
        Console.WriteLine("🔍 Đang lấy danh sách card mạng từ PerformanceCounter...\n");

        var category = new PerformanceCounterCategory("Network Interface");
        var instanceNames = category.GetInstanceNames();

        for (int i = 0; i < instanceNames.Length; i++)
        {
            Console.WriteLine($"{i + 1}. {instanceNames[i]}");
        }

        Console.Write("\n👉 Nhập số thứ tự card mạng để theo dõi: ");
        if (!int.TryParse(Console.ReadLine(), out int index) || index < 1 || index > instanceNames.Length)
        {
            Console.WriteLine("❌ Lựa chọn không hợp lệ.");
            return;
        }

        string selectedInstanceName = instanceNames[index - 1];

        // Cố gắng map sang NetworkInterface để lấy tốc độ tối đa
        var nic = NetworkInterface.GetAllNetworkInterfaces()
            .FirstOrDefault(n =>
                selectedInstanceName.IndexOf(n.Description, StringComparison.OrdinalIgnoreCase) >= 0 ||
                selectedInstanceName.IndexOf(n.Name, StringComparison.OrdinalIgnoreCase) >= 0);

        double maxSpeedMbps;
        if (nic != null)
        {
            maxSpeedMbps = nic.Speed / 1_000_000.0;
        }
        else
        {
            Console.Write("❓ Không xác định được tốc độ card. Nhập thủ công tốc độ tối đa (Mbps): ");
            maxSpeedMbps = double.TryParse(Console.ReadLine(), out double userSpeed) ? userSpeed : 100;
        }

        var sentCounter = new PerformanceCounter("Network Interface", "Bytes Sent/sec", selectedInstanceName);
        var recvCounter = new PerformanceCounter("Network Interface", "Bytes Received/sec", selectedInstanceName);

        Console.Clear();
        Console.WriteLine($"🎯 Đang theo dõi card: {selectedInstanceName}");
        Console.WriteLine($"⚡ Tốc độ tối đa: {maxSpeedMbps} Mbps\n");

        while (true)
        {
            float sentBytes = sentCounter.NextValue();
            float recvBytes = recvCounter.NextValue();
            float totalBytes = sentBytes + recvBytes;

            double totalMbps = totalBytes * 8 / 1_000_000.0;
            double percent = (totalMbps / maxSpeedMbps) * 100.0;

            Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] ➜ {totalMbps:F2} Mbps ({percent:F1}%) | Gửi: {sentBytes * 8 / 1_000_000:F2} Mbps, Nhận: {recvBytes * 8 / 1_000_000:F2} Mbps");

            Thread.Sleep(1000);
        }
    }
}
